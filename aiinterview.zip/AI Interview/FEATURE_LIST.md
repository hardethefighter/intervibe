# Feature List

## Completed Features

- Web-based interview trainer
- Python Flask backend
- Java Swing optional GUI
- HR questions
- Technical questions
- Resume-based questions
- Project-based questions
- Resume upload
- TXT resume parsing
- PDF resume parsing
- DOCX resume parsing
- Skill detection
- Project detection
- Voice question reading
- Voice answer input
- Answer timer
- Keyword-based scoring
- Answer quality scoring
- Feedback generation
- Matched keyword display
- Missing keyword display
- Recent result display
- CSV result saving
- Automatic next question
- Beginner-friendly setup instructions

## Future Enhancements

- Database integration
- Candidate login
- Admin panel
- Interview report download
- Charts for performance analysis
- More question categories
- OpenAI-powered detailed feedback
- Video interview mode
- Multiple interview rounds
