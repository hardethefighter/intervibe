# Module Explanation

## python_backend/app.py

This is the main Flask backend file. It defines API routes for:

- Home website
- Categories
- Resume upload
- Question generation
- Answer evaluation
- Results history

## python_backend/resume_parser.py

This file extracts text from resume documents.

Supported formats:

- TXT
- PDF
- DOCX

Libraries used:

- PyPDF2 for PDF
- python-docx for DOCX

## python_backend/resume_analyzer.py

This file detects important skills and projects from resume text. It uses a predefined list of common technical skills and simple project extraction patterns.

It also creates personalized interview questions such as:

- You mentioned Python in your resume. Explain how you used it in a project.
- Your resume mentions AI Interview Trainer. Explain the project architecture and your contribution.

## python_backend/evaluator.py

This file evaluates candidate answers.

It checks:

- Matched keywords
- Missing keywords
- Answer length
- Clarity markers
- Final score
- Grade
- Feedback

## python_backend/interview_data.py

This file stores predefined HR and technical questions. These are used when the candidate does not upload a resume or when general questions are needed.

## python_backend/static/js/app.js

This is the main frontend logic.

It handles:

- Resume upload
- Question loading
- Voice question reading
- Voice answer input
- Timer
- Answer submission
- Auto next question
- Results display

## python_backend/templates/index.html

This is the main website page. It contains the user interface for candidate details, resume upload, answer box, feedback, and recent results.

## python_backend/static/css/styles.css

This file controls the website design, layout, colors, spacing, panels, buttons, and mobile responsiveness.

## java_gui/src/com/interviewtrainer/InterviewTrainerApp.java

This is the optional Java Swing interface. It connects to the Python backend and allows the candidate to answer questions from a desktop GUI.
