# Sample Input and Output

## Sample Resume Text

```text
Project: AI Interview Trainer System.
Developed a Flask backend and web interface for interview practice.
Skills: Python, Flask, SQL, HTML, CSS, JavaScript.
The system evaluates answers and saves performance results.
```

## Detected Skills

```text
python, flask, sql, html, css, javascript
```

## Sample Generated Question

```text
You mentioned Python in your resume. Explain how you used it in a project.
```

## Sample Answer

```text
I used Python in my AI Interview Trainer project to build the backend logic.
Python handled question generation, answer evaluation, keyword matching, and result saving.
I also used Flask to create API routes for the website.
```

## Sample Evaluation Output

```text
Score: 82/100
Grade: Good

Feedback:
Good answer. You covered several key points, but it can be more specific.
Matched keywords: python, project, implementation, result.
Suggested keywords to include: example.
```

## Sample HR Question

```text
Walk me through your resume and explain why your skills fit this role.
```

## Sample Project Question

```text
Your resume mentions AI Interview Trainer System. Explain the project architecture and your contribution.
```
