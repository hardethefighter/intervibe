# AI Interview Trainer System - Project Report

## Project Title

AI Interview Trainer System

## Project Overview

The AI Interview Trainer System is a web-based interview practice application. It simulates a real job interview by asking HR, technical, resume-based, and project-based questions. The system can analyze a candidate resume, detect skills and projects, ask interview questions aloud, accept typed or voice answers, evaluate answers, provide feedback, and save performance results.

This project is suitable for a diploma final review because it combines Python backend development, web development, resume analysis, voice interaction, scoring logic, and optional Java GUI support.

## Objectives

- Simulate a real interview environment.
- Ask questions based on HR, technical knowledge, resume skills, and projects.
- Accept answers using text or voice input.
- Ask interview questions using voice output.
- Evaluate answers using keyword matching and answer quality.
- Save candidate performance for later review.
- Provide a clean and simple web interface.

## Main Features

- Resume upload support for TXT, PDF, and DOCX files.
- Resume text extraction.
- Skill and project detection from resume content.
- Resume-based interview question generation.
- Automatic voice question reading.
- Voice answer input using browser microphone.
- Automatic next question after answer submission.
- Timer for each answer.
- Score, grade, matched keywords, missing keywords, and feedback.
- Recent result history.
- CSV-based result saving.

## Technologies Used

- Python
- Flask
- HTML
- CSS
- JavaScript
- Web Speech API
- PyPDF2
- python-docx
- Java Swing
- CSV file storage

## System Modules

### Python Backend

The Python backend handles:

- Question generation
- Resume document parsing
- Resume skill analysis
- Answer evaluation
- Score calculation
- Feedback generation
- Result saving
- API endpoints for frontend communication

### Website Frontend

The website handles:

- Candidate input
- Resume upload
- Category selection
- Question display
- Voice question reading
- Voice answer input
- Answer submission
- Feedback and result display

### Java GUI

The Java Swing GUI is an optional desktop interface. It connects to the same Python backend and supports question display, text answer input, feedback, and score display.

## How The System Works

1. The candidate opens the website.
2. The candidate enters their name.
3. The candidate uploads a resume document.
4. Python extracts text from the resume.
5. Python detects skills and project details.
6. The backend generates a question related to the resume.
7. The website displays and speaks the question aloud.
8. The candidate answers using text or voice.
9. Python evaluates the answer.
10. The website shows score, grade, feedback, matched keywords, and missing keywords.
11. The result is saved in a CSV file.
12. The next question starts automatically.

## Scoring System

The answer is scored out of 100:

- 60 marks for expected keywords
- 25 marks for answer length and detail
- 15 marks for clarity signals such as examples and explanations

Grades:

- 85 to 100: Excellent
- 70 to 84: Good
- 50 to 69: Average
- Below 50: Needs Improvement

## Conclusion

The AI Interview Trainer System is a practical and impressive final review project. It helps students prepare for interviews by creating questions from their own resume and skills. It also demonstrates backend development, frontend design, document processing, voice features, and scoring logic in one complete system.
