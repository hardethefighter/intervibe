# Viva and Review Questions

## 1. What is your project?

My project is an AI Interview Trainer System. It helps candidates practice interviews by asking HR, technical, resume-based, and project-based questions.

## 2. Why did you choose this project?

I chose this project because interview preparation is useful for students. It also combines many technologies such as Python, Flask, web development, resume analysis, voice input, and answer evaluation.

## 3. How does resume-based interview work?

The candidate uploads a resume document. The backend extracts text from the resume, detects skills and projects, and generates questions related to those skills.

## 4. Which file handles resume parsing?

`resume_parser.py` handles resume parsing. It supports TXT, PDF, and DOCX files.

## 5. How are answers evaluated?

Answers are evaluated using keyword matching and answer quality. The system checks expected keywords, answer length, and clarity signals like examples.

## 6. What is the use of Flask in this project?

Flask is used to build the backend API and serve the website.

## 7. How does voice input work?

Voice input works using the browser Web Speech API. The candidate speaks into the microphone and the browser converts speech into text.

## 8. How does the system ask questions in voice?

The website uses browser speech synthesis to read each interview question aloud automatically.

## 9. Where are results saved?

Results are saved in a CSV file at `python_backend/results/performance_results.csv`.

## 10. What are future improvements?

Future improvements include login system, database storage, advanced AI feedback, emotion analysis, video interview mode, and dashboard charts.
