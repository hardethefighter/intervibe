# Setup Guide

## Required Software

- Python 3.10 or newer
- Java JDK 17 or newer, optional for Java GUI
- Chrome or Microsoft Edge for voice features

## Install Python Libraries

Open PowerShell:

```powershell
cd C:\Users\DELL\Pictures\JARVIS-master\AI-Interview-Trainer-System\python_backend
pip install -r requirements.txt
```

## Start Website

```powershell
cd C:\Users\DELL\Pictures\JARVIS-master\AI-Interview-Trainer-System\python_backend
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

## Use Resume Upload

1. Open the website.
2. Enter candidate name.
3. Select interview category.
4. Upload TXT, PDF, or DOCX resume.
5. Click `Analyze Resume & Start`.
6. Allow microphone permission if using voice answer.
7. Answer the question.
8. Submit answer.
9. The next question starts automatically.

## Optional Java GUI

Compile:

```powershell
cd C:\Users\DELL\Pictures\JARVIS-master\AI-Interview-Trainer-System\java_gui
javac -d out src/com/interviewtrainer/InterviewTrainerApp.java
```

Run:

```powershell
java -cp out com.interviewtrainer.InterviewTrainerApp
```

The Python backend must be running before starting the Java GUI.
