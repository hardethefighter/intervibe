package com.interviewtrainer;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InterviewTrainerApp extends JFrame {
    private static final String BACKEND_URL = "http://127.0.0.1:5000";

    private final JTextField nameField = new JTextField("Student");
    private final JComboBox<String> categoryBox = new JComboBox<>(new String[]{"Mixed", "HR", "Technical"});
    private final JLabel timerLabel = new JLabel("Time: 120s");
    private final JLabel scoreLabel = new JLabel("Score: --");
    private final JTextArea questionArea = new JTextArea();
    private final JTextArea answerArea = new JTextArea();
    private final JTextArea feedbackArea = new JTextArea();
    private final JButton startButton = new JButton("Start Interview");
    private final JButton submitButton = new JButton("Submit Answer");

    private Timer countdownTimer;
    private int currentQuestionId = -1;
    private int secondsLeft = 120;
    private int secondsUsed = 0;

    public InterviewTrainerApp() {
        setTitle("AI Interview Trainer System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(900, 620));
        setLocationRelativeTo(null);

        setContentPane(buildUi());
        bindActions();
        setQuestionState(false);
    }

    private JPanel buildUi() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBorder(new EmptyBorder(16, 16, 16, 16));
        root.setBackground(new Color(246, 248, 250));

        JLabel title = new JLabel("AI Interview Trainer System");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(new Color(28, 43, 57));

        JPanel top = new JPanel(new BorderLayout(12, 8));
        top.setOpaque(false);
        top.add(title, BorderLayout.NORTH);
        top.add(buildControls(), BorderLayout.CENTER);

        root.add(top, BorderLayout.NORTH);
        root.add(buildMainPanel(), BorderLayout.CENTER);
        root.add(buildBottomPanel(), BorderLayout.SOUTH);

        return root;
    }

    private JPanel buildControls() {
        JPanel controls = new JPanel(new GridBagLayout());
        controls.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        controls.add(new JLabel("Candidate"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        controls.add(nameField, gbc);

        gbc.gridx = 2;
        gbc.weightx = 0;
        controls.add(new JLabel("Category"), gbc);

        gbc.gridx = 3;
        controls.add(categoryBox, gbc);

        gbc.gridx = 4;
        timerLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        controls.add(timerLabel, gbc);

        gbc.gridx = 5;
        scoreLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        controls.add(scoreLabel, gbc);

        return controls;
    }

    private JSplitPane buildMainPanel() {
        JPanel left = new JPanel(new BorderLayout(8, 8));
        left.setOpaque(false);

        questionArea.setEditable(false);
        questionArea.setLineWrap(true);
        questionArea.setWrapStyleWord(true);
        questionArea.setFont(new Font("Segoe UI", Font.BOLD, 18));
        questionArea.setText("Click Start Interview to receive your first question.");
        questionArea.setBorder(new EmptyBorder(12, 12, 12, 12));

        answerArea.setLineWrap(true);
        answerArea.setWrapStyleWord(true);
        answerArea.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        answerArea.setBorder(new EmptyBorder(12, 12, 12, 12));

        left.add(labeledPanel("Question", new JScrollPane(questionArea)), BorderLayout.NORTH);
        left.add(labeledPanel("Your Answer", new JScrollPane(answerArea)), BorderLayout.CENTER);

        feedbackArea.setEditable(false);
        feedbackArea.setLineWrap(true);
        feedbackArea.setWrapStyleWord(true);
        feedbackArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        feedbackArea.setBorder(new EmptyBorder(12, 12, 12, 12));
        feedbackArea.setText("Feedback and score will appear here after submission.");

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                left,
                labeledPanel("Feedback", new JScrollPane(feedbackArea))
        );
        splitPane.setResizeWeight(0.62);
        splitPane.setBorder(null);
        return splitPane;
    }

    private JPanel buildBottomPanel() {
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.setOpaque(false);
        startButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        submitButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        bottom.add(startButton);
        bottom.add(submitButton);
        return bottom;
    }

    private JPanel labeledPanel(String label, Component component) {
        JPanel panel = new JPanel(new BorderLayout(6, 6));
        panel.setOpaque(false);

        JLabel title = new JLabel(label);
        title.setFont(new Font("Segoe UI", Font.BOLD, 14));
        title.setForeground(new Color(45, 62, 80));

        panel.add(title, BorderLayout.NORTH);
        panel.add(component, BorderLayout.CENTER);
        return panel;
    }

    private void bindActions() {
        startButton.addActionListener(event -> loadQuestion());
        submitButton.addActionListener(event -> submitAnswer());
    }

    private void loadQuestion() {
        startButton.setEnabled(false);
        feedbackArea.setText("Loading question from Python backend...");

        new SwingWorker<Question, Void>() {
            @Override
            protected Question doInBackground() throws Exception {
                String category = encode(categoryBox.getSelectedItem().toString());
                String response = sendGet(BACKEND_URL + "/question?category=" + category);
                int id = Integer.parseInt(readJsonValue(response, "id"));
                String question = unescapeJson(readJsonValue(response, "question"));
                int timer = Integer.parseInt(readJsonValue(response, "timer_seconds"));
                return new Question(id, question, timer);
            }

            @Override
            protected void done() {
                try {
                    Question question = get();
                    currentQuestionId = question.id;
                    questionArea.setText(question.text);
                    answerArea.setText("");
                    feedbackArea.setText("Write your answer clearly. Include important terms and a short example when possible.");
                    scoreLabel.setText("Score: --");
                    setQuestionState(true);
                    startTimer(question.timerSeconds);
                } catch (Exception ex) {
                    feedbackArea.setText("Could not load question. Make sure the Python backend is running.\n\n" + ex.getMessage());
                } finally {
                    startButton.setEnabled(true);
                }
            }
        }.execute();
    }

    private void submitAnswer() {
        String answer = answerArea.getText().trim();
        if (currentQuestionId == -1) {
            JOptionPane.showMessageDialog(this, "Please start the interview first.");
            return;
        }
        if (answer.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please type your answer before submitting.");
            return;
        }

        stopTimer();
        submitButton.setEnabled(false);
        feedbackArea.setText("Evaluating your answer...");

        new SwingWorker<Evaluation, Void>() {
            @Override
            protected Evaluation doInBackground() throws Exception {
                String json = "{"
                        + "\"question_id\":" + currentQuestionId + ","
                        + "\"candidate_name\":\"" + escapeJson(nameField.getText().trim()) + "\","
                        + "\"answer\":\"" + escapeJson(answer) + "\","
                        + "\"time_taken_seconds\":" + secondsUsed
                        + "}";

                String response = sendPost(BACKEND_URL + "/evaluate", json);
                int score = Integer.parseInt(readJsonValue(response, "score"));
                String grade = unescapeJson(readJsonValue(response, "grade"));
                String feedback = unescapeJson(readJsonValue(response, "feedback"));
                return new Evaluation(score, grade, feedback);
            }

            @Override
            protected void done() {
                try {
                    Evaluation evaluation = get();
                    scoreLabel.setText("Score: " + evaluation.score + "/100");
                    feedbackArea.setText("Grade: " + evaluation.grade + "\n\n" + evaluation.feedback);
                    setQuestionState(false);
                } catch (Exception ex) {
                    feedbackArea.setText("Could not evaluate answer.\n\n" + ex.getMessage());
                    submitButton.setEnabled(true);
                }
            }
        }.execute();
    }

    private void startTimer(int totalSeconds) {
        stopTimer();
        secondsLeft = totalSeconds;
        secondsUsed = 0;
        timerLabel.setText("Time: " + secondsLeft + "s");

        countdownTimer = new Timer(1000, event -> {
            secondsLeft--;
            secondsUsed++;
            timerLabel.setText("Time: " + secondsLeft + "s");

            if (secondsLeft <= 0) {
                stopTimer();
                submitButton.setEnabled(false);
                feedbackArea.setText("Time is up. You can start a new question or submit earlier next time.");
            }
        });
        countdownTimer.start();
    }

    private void stopTimer() {
        if (countdownTimer != null) {
            countdownTimer.stop();
        }
    }

    private void setQuestionState(boolean active) {
        answerArea.setEnabled(active);
        submitButton.setEnabled(active);
    }

    private String sendGet(String targetUrl) throws Exception {
        HttpURLConnection connection = openConnection(targetUrl, "GET");
        return readResponse(connection);
    }

    private String sendPost(String targetUrl, String jsonBody) throws Exception {
        HttpURLConnection connection = openConnection(targetUrl, "POST");
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json");

        try (OutputStream output = connection.getOutputStream()) {
            output.write(jsonBody.getBytes(StandardCharsets.UTF_8));
        }

        return readResponse(connection);
    }

    private HttpURLConnection openConnection(String targetUrl, String method) throws Exception {
        URL url = URI.create(targetUrl).toURL();
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod(method);
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        return connection;
    }

    private String readResponse(HttpURLConnection connection) throws Exception {
        int status = connection.getResponseCode();
        InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
            }
            if (status >= 400) {
                throw new RuntimeException("Backend returned HTTP " + status + ": " + builder);
            }
            return builder.toString();
        }
    }

    private String readJsonValue(String json, String key) {
        Pattern stringPattern = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"");
        Matcher stringMatcher = stringPattern.matcher(json);
        if (stringMatcher.find()) {
            return stringMatcher.group(1);
        }

        Pattern numberPattern = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*(-?\\d+)");
        Matcher numberMatcher = numberPattern.matcher(json);
        if (numberMatcher.find()) {
            return numberMatcher.group(1);
        }

        throw new IllegalArgumentException("Could not read JSON field: " + key);
    }

    private String encode(String text) {
        return text.replace(" ", "%20");
    }

    private String escapeJson(String text) {
        return text
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private String unescapeJson(String text) {
        return text
                .replace("\\n", "\n")
                .replace("\\r", "\r")
                .replace("\\t", "\t")
                .replace("\\\"", "\"")
                .replace("\\\\", "\\");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InterviewTrainerApp().setVisible(true));
    }

    private record Question(int id, String text, int timerSeconds) {
    }

    private record Evaluation(int score, String grade, String feedback) {
    }
}
