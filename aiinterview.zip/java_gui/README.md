# Java GUI

This folder contains the Java Swing interface for the AI Interview Trainer System.

Compile:

```bash
javac -d out src/com/interviewtrainer/InterviewTrainerApp.java
```

Run:

```bash
java -cp out com.interviewtrainer.InterviewTrainerApp
```

Start the Python backend before opening the GUI.
