const candidateName = document.querySelector("#candidateName");
const categorySelect = document.querySelector("#categorySelect");
const resumeFile = document.querySelector("#resumeFile");
const uploadResumeBtn = document.querySelector("#uploadResumeBtn");
const resumeUploadStatus = document.querySelector("#resumeUploadStatus");
const skillsText = document.querySelector("#skillsText");
const resumeText = document.querySelector("#resumeText");
const timerText = document.querySelector("#timerText");
const scoreText = document.querySelector("#scoreText");
const gradeText = document.querySelector("#gradeText");
const questionMeta = document.querySelector("#questionMeta");
const timeUsedText = document.querySelector("#timeUsedText");
const categoryBadge = document.querySelector("#categoryBadge");
const questionText = document.querySelector("#questionText");
const answerText = document.querySelector("#answerText");
const helperText = document.querySelector("#helperText");
const feedbackText = document.querySelector("#feedbackText");
const matchedText = document.querySelector("#matchedText");
const missingText = document.querySelector("#missingText");
const startBtn = document.querySelector("#startBtn");
const resetBtn = document.querySelector("#resetBtn");
const submitBtn = document.querySelector("#submitBtn");
const readQuestionBtn = document.querySelector("#readQuestionBtn");
const voiceBtn = document.querySelector("#voiceBtn");
const stopVoiceBtn = document.querySelector("#stopVoiceBtn");
const voiceStatus = document.querySelector("#voiceStatus");
const voiceToolbar = document.querySelector(".voice-toolbar");
const refreshResultsBtn = document.querySelector("#refreshResultsBtn");
const resultsList = document.querySelector("#resultsList");

let currentQuestionId = null;
let secondsLeft = 120;
let secondsUsed = 0;
let timer = null;
let recognition = null;
let isListening = false;
let nextQuestionTimer = null;
let nextQuestionCountdownTimer = null;

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

function setBusy(isBusy) {
    startBtn.disabled = isBusy;
    submitBtn.disabled = isBusy || !currentQuestionId;
}

function stopTimer() {
    if (timer) {
        clearInterval(timer);
        timer = null;
    }
}

function cancelNextQuestion() {
    if (nextQuestionTimer) {
        clearTimeout(nextQuestionTimer);
        nextQuestionTimer = null;
    }
    if (nextQuestionCountdownTimer) {
        clearInterval(nextQuestionCountdownTimer);
        nextQuestionCountdownTimer = null;
    }
}

function setupVoiceInput() {
    if (!SpeechRecognition) {
        voiceStatus.textContent = "Voice input is not supported in this browser. Use Chrome or Edge.";
        voiceBtn.disabled = true;
        stopVoiceBtn.disabled = true;
        return;
    }

    recognition = new SpeechRecognition();
    recognition.lang = "en-IN";
    recognition.continuous = true;
    recognition.interimResults = true;

    recognition.onstart = () => {
        isListening = true;
        voiceToolbar.classList.add("is-listening");
        voiceBtn.disabled = true;
        stopVoiceBtn.disabled = false;
        voiceStatus.textContent = "Listening... speak your answer clearly.";
    };

    recognition.onresult = (event) => {
        let finalText = "";
        let interimText = "";

        for (let i = event.resultIndex; i < event.results.length; i += 1) {
            const transcript = event.results[i][0].transcript.trim();
            if (event.results[i].isFinal) {
                finalText += `${transcript} `;
            } else {
                interimText += `${transcript} `;
            }
        }

        if (finalText) {
            const separator = answerText.value.trim() ? " " : "";
            answerText.value = `${answerText.value.trim()}${separator}${finalText.trim()}`;
        }

        if (interimText) {
            voiceStatus.textContent = `Listening: ${interimText.trim()}`;
        }
    };

    recognition.onerror = (event) => {
        stopVoiceInput();
        if (event.error === "not-allowed") {
            voiceStatus.textContent = "Microphone permission was blocked. Allow microphone access and try again.";
        } else {
            voiceStatus.textContent = `Voice input error: ${event.error}`;
        }
    };

    recognition.onend = () => {
        isListening = false;
        voiceToolbar.classList.remove("is-listening");
        stopVoiceBtn.disabled = true;
        voiceBtn.disabled = !currentQuestionId || answerText.disabled;
        if (currentQuestionId && !answerText.disabled) {
            voiceStatus.textContent = "Voice input stopped. You can start again or submit your answer.";
        }
    };

    voiceStatus.textContent = "Voice input ready. Start an interview, then click Start Voice Answer.";
}

function startVoiceInput() {
    if (!recognition || !currentQuestionId || answerText.disabled || isListening) {
        return;
    }

    try {
        recognition.start();
    } catch (error) {
        voiceStatus.textContent = `Could not start voice input: ${error.message}`;
    }
}

function stopVoiceInput() {
    if (recognition && isListening) {
        recognition.stop();
    }
    isListening = false;
    voiceToolbar.classList.remove("is-listening");
    stopVoiceBtn.disabled = true;
    voiceBtn.disabled = !currentQuestionId || answerText.disabled;
}

function readQuestionAloud() {
    if (!("speechSynthesis" in window)) {
        voiceStatus.textContent = "Question reading is not supported in this browser.";
        return;
    }

    const text = questionText.textContent.trim();
    if (!text || !currentQuestionId) {
        return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-IN";
    utterance.rate = 0.92;
    utterance.pitch = 1;
    window.speechSynthesis.speak(utterance);
    voiceStatus.textContent = "Reading the interview question aloud.";
}

function autoReadQuestion() {
    if (!("speechSynthesis" in window)) {
        return;
    }

    window.setTimeout(() => {
        readQuestionAloud();
    }, 350);
}

function startTimer(totalSeconds) {
    stopTimer();
    secondsLeft = totalSeconds;
    secondsUsed = 0;
    timerText.textContent = `${secondsLeft}s`;
    timeUsedText.textContent = "0s";
    timerText.className = "";

    timer = setInterval(() => {
        secondsLeft -= 1;
        secondsUsed += 1;
        timerText.textContent = `${secondsLeft}s`;
        timeUsedText.textContent = `${secondsUsed}s`;

        if (secondsLeft <= 30) {
            timerText.className = "is-warning";
        }

        if (secondsLeft <= 10) {
            timerText.className = "is-danger";
        }

        if (secondsLeft <= 0) {
            stopTimer();
            answerText.disabled = true;
            submitBtn.disabled = true;
            helperText.textContent = "Time is up. Start a new question to continue practicing.";
        }
    }, 1000);
}

function resetScreen() {
    stopTimer();
    cancelNextQuestion();
    stopVoiceInput();
    if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
    }
    currentQuestionId = null;
    secondsLeft = 120;
    secondsUsed = 0;
    timerText.textContent = "120s";
    timerText.className = "";
    scoreText.textContent = "--";
    gradeText.textContent = "--";
    questionMeta.textContent = "Not started";
    timeUsedText.textContent = "0s";
    categoryBadge.textContent = "Ready";
    questionText.textContent = "Select a category and start your interview.";
    answerText.value = "";
    answerText.disabled = true;
    readQuestionBtn.disabled = true;
    voiceBtn.disabled = true;
    stopVoiceBtn.disabled = true;
    submitBtn.disabled = true;
    helperText.textContent = "Your feedback will appear after submission.";
    feedbackText.textContent = "No answer submitted yet.";
    matchedText.textContent = "--";
    missingText.textContent = "--";
    if (SpeechRecognition) {
        voiceStatus.textContent = "Voice input ready. Start an interview, then click Start Voice Answer.";
    }
}

async function fetchJson(url, options = {}) {
    const response = await fetch(url, options);
    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.error || "Request failed");
    }

    return data;
}

async function uploadResumeAndStart() {
    const file = resumeFile.files[0];

    if (!file) {
        resumeUploadStatus.textContent = "Choose a resume document first.";
        resumeUploadStatus.className = "small-status is-danger";
        return;
    }

    cancelNextQuestion();
    uploadResumeBtn.disabled = true;
    startBtn.disabled = true;
    resumeUploadStatus.textContent = "Analyzing resume document...";
    resumeUploadStatus.className = "small-status";

    try {
        const formData = new FormData();
        formData.append("resume", file);
        formData.append("skills_text", skillsText.value.trim());

        const data = await fetchJson("/upload-resume", {
            method: "POST",
            body: formData,
        });

        resumeText.value = data.resume_text;
        if (data.skills_text) {
            skillsText.value = data.skills_text;
        }

        const skills = data.resume_context.skills || [];
        const projects = data.resume_context.projects || [];
        const skillsLine = skills.length ? `Skills: ${skills.join(", ")}.` : "No clear skills detected.";
        const projectsLine = projects.length ? ` Projects: ${projects.join("; ")}.` : "";
        resumeUploadStatus.textContent = `Resume analyzed. ${skillsLine}${projectsLine} Starting interview...`;
        resumeUploadStatus.className = "small-status is-success";

        await loadQuestion();
    } catch (error) {
        resumeUploadStatus.textContent = `Resume analysis failed: ${error.message}`;
        resumeUploadStatus.className = "small-status is-danger";
    } finally {
        uploadResumeBtn.disabled = false;
        startBtn.disabled = false;
    }
}

async function loadQuestion() {
    cancelNextQuestion();
    setBusy(true);
    feedbackText.textContent = "Loading question...";

    try {
        const data = await fetchJson("/question", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                category: categorySelect.value,
                resume_text: resumeText.value.trim(),
                skills_text: skillsText.value.trim(),
            }),
        });
        currentQuestionId = data.id;
        categoryBadge.textContent = data.category;
        questionMeta.textContent = `#${data.id} ${data.category}`;
        questionText.textContent = data.question;
        answerText.value = "";
        answerText.disabled = false;
        answerText.focus();
        readQuestionBtn.disabled = false;
        voiceBtn.disabled = !recognition;
        stopVoiceBtn.disabled = true;
        scoreText.textContent = "--";
        gradeText.textContent = "--";
        feedbackText.textContent = buildQuestionGuidance(data.resume_context);
        matchedText.textContent = "--";
        missingText.textContent = "--";
        helperText.textContent = "Timer is running.";
        voiceStatus.textContent = recognition
            ? "The question will be spoken aloud. Voice input is ready after that."
            : "Voice input is not supported in this browser. You can still type.";
        submitBtn.disabled = false;
        startTimer(data.timer_seconds);
        autoReadQuestion();
    } catch (error) {
        feedbackText.textContent = `Could not load a question: ${error.message}`;
        currentQuestionId = null;
        submitBtn.disabled = true;
    } finally {
        startBtn.disabled = false;
    }
}

function buildQuestionGuidance(context) {
    const skills = context?.skills || [];
    const projects = context?.projects || [];

    if (!skills.length && !projects.length) {
        return "Answer the question naturally. Add skills, project context, and one example for a stronger score.";
    }

    const skillText = skills.length ? `Detected skills: ${skills.join(", ")}.` : "";
    const projectText = projects.length ? `Resume project clues: ${projects.join("; ")}.` : "";
    return `${skillText} ${projectText}\nUse these resume details in your answer with a clear example.`;
}

async function submitAnswer() {
    const answer = answerText.value.trim();

    if (!currentQuestionId) {
        feedbackText.textContent = "Start the interview before submitting.";
        return;
    }

    if (!answer) {
        feedbackText.textContent = "Please type your answer before submitting.";
        return;
    }

    stopTimer();
    stopVoiceInput();
    setBusy(true);
    feedbackText.textContent = "Evaluating answer...";

    try {
        const data = await fetchJson("/evaluate", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                question_id: currentQuestionId,
                candidate_name: candidateName.value.trim() || "Student",
                answer,
                time_taken_seconds: secondsUsed,
            }),
        });

        scoreText.textContent = `${data.score}/100`;
        gradeText.textContent = data.grade;
        gradeText.className = data.score >= 70 ? "is-success" : data.score >= 50 ? "is-warning" : "is-danger";
        feedbackText.textContent = data.feedback;
        matchedText.textContent = data.matched_keywords.length ? data.matched_keywords.join(", ") : "None";
        missingText.textContent = data.missing_keywords.length ? data.missing_keywords.join(", ") : "None";
        helperText.textContent = "Result saved. Start another question when ready.";
        answerText.disabled = true;
        readQuestionBtn.disabled = true;
        voiceBtn.disabled = true;
        stopVoiceBtn.disabled = true;
        currentQuestionId = null;
        await loadResults();
        scheduleNextQuestion();
    } catch (error) {
        feedbackText.textContent = `Could not evaluate the answer: ${error.message}`;
        submitBtn.disabled = false;
    } finally {
        startBtn.disabled = false;
    }
}

function scheduleNextQuestion() {
    let countdown = 4;
    helperText.textContent = `Result saved. Next question starts in ${countdown}s.`;
    startBtn.disabled = false;
    submitBtn.disabled = true;

    nextQuestionCountdownTimer = setInterval(() => {
        countdown -= 1;
        if (countdown > 0) {
            helperText.textContent = `Result saved. Next question starts in ${countdown}s.`;
        }
    }, 1000);

    nextQuestionTimer = setTimeout(() => {
        cancelNextQuestion();
        nextQuestionTimer = null;
        loadQuestion();
    }, 4000);
}

async function loadResults() {
    try {
        const data = await fetchJson("/results");
        const recent = data.results.slice(-5).reverse();

        if (!recent.length) {
            resultsList.innerHTML = '<p class="empty-state">No saved results yet.</p>';
            return;
        }

        resultsList.innerHTML = recent.map((item) => `
            <article class="result-item">
                <strong>${escapeHtml(item.candidate_name)} - ${escapeHtml(item.score)}/100</strong>
                <span>${escapeHtml(item.grade)} | ${escapeHtml(item.category)} | ${escapeHtml(item.time_taken_seconds)}s</span>
                <span>${escapeHtml(item.timestamp)}</span>
            </article>
        `).join("");
    } catch (error) {
        resultsList.innerHTML = `<p class="empty-state">Could not load results: ${escapeHtml(error.message)}</p>`;
    }
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

startBtn.addEventListener("click", loadQuestion);
uploadResumeBtn.addEventListener("click", uploadResumeAndStart);
submitBtn.addEventListener("click", submitAnswer);
resetBtn.addEventListener("click", resetScreen);
readQuestionBtn.addEventListener("click", readQuestionAloud);
voiceBtn.addEventListener("click", startVoiceInput);
stopVoiceBtn.addEventListener("click", stopVoiceInput);
refreshResultsBtn.addEventListener("click", loadResults);

setupVoiceInput();
resetScreen();
loadResults();
