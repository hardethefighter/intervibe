"""Resume document text extraction helpers."""

from __future__ import annotations

from io import BytesIO


ALLOWED_EXTENSIONS = {".txt", ".pdf", ".docx"}


def extract_resume_text(filename: str, file_bytes: bytes) -> str:
    lower_name = filename.lower()

    if lower_name.endswith(".txt"):
        return _extract_txt(file_bytes)

    if lower_name.endswith(".pdf"):
        return _extract_pdf(file_bytes)

    if lower_name.endswith(".docx"):
        return _extract_docx(file_bytes)

    raise ValueError("Unsupported file type. Upload .txt, .pdf, or .docx resume files.")


def _extract_txt(file_bytes: bytes) -> str:
    for encoding in ("utf-8", "utf-16", "latin-1"):
        try:
            return file_bytes.decode(encoding).strip()
        except UnicodeDecodeError:
            continue
    return file_bytes.decode("utf-8", errors="ignore").strip()


def _extract_pdf(file_bytes: bytes) -> str:
    try:
        from PyPDF2 import PdfReader
    except ImportError as exc:
        raise RuntimeError("PDF support requires PyPDF2. Run: pip install -r requirements.txt") from exc

    reader = PdfReader(BytesIO(file_bytes))
    pages = [page.extract_text() or "" for page in reader.pages]
    return "\n".join(pages).strip()


def _extract_docx(file_bytes: bytes) -> str:
    try:
        from docx import Document
    except ImportError as exc:
        raise RuntimeError("DOCX support requires python-docx. Run: pip install -r requirements.txt") from exc

    document = Document(BytesIO(file_bytes))
    paragraphs = [paragraph.text for paragraph in document.paragraphs if paragraph.text.strip()]
    return "\n".join(paragraphs).strip()
