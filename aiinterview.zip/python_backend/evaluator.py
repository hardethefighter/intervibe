"""Answer evaluation logic for the AI Interview Trainer System."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Iterable


@dataclass
class EvaluationResult:
    score: int
    grade: str
    matched_keywords: list[str]
    missing_keywords: list[str]
    feedback: str


def _normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower()).strip()


def _count_words(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text))


def _keyword_score(answer: str, keywords: Iterable[str]) -> tuple[int, list[str], list[str]]:
    keywords = list(keywords)
    normalized_answer = _normalize(answer)
    matched = []
    missing = []

    for keyword in keywords:
        if _normalize(keyword) in normalized_answer:
            matched.append(keyword)
        else:
            missing.append(keyword)

    if not keywords:
        return 0, matched, missing

    return round((len(matched) / len(keywords)) * 60), matched, missing


def _quality_score(answer: str) -> int:
    """Score answer quality using beginner-friendly heuristics.

    The final score is intentionally simple and explainable:
    - up to 60 points for expected keywords
    - up to 25 points for length/detail
    - up to 15 points for clarity signals
    """

    word_count = _count_words(answer)
    normalized = _normalize(answer)
    score = 0

    if word_count >= 60:
        score += 25
    elif word_count >= 35:
        score += 20
    elif word_count >= 18:
        score += 13
    elif word_count >= 8:
        score += 7

    clarity_markers = ["because", "for example", "such as", "therefore", "also", "project", "experience"]
    marker_hits = sum(1 for marker in clarity_markers if marker in normalized)
    score += min(15, marker_hits * 4)

    return score


def _grade(score: int) -> str:
    if score >= 85:
        return "Excellent"
    if score >= 70:
        return "Good"
    if score >= 50:
        return "Average"
    return "Needs Improvement"


def _basic_feedback(score: int, matched: list[str], missing: list[str], sample_answer: str) -> str:
    if score >= 85:
        opening = "Excellent answer. You covered the important points and gave enough detail."
    elif score >= 70:
        opening = "Good answer. You covered several key points, but it can be more specific."
    elif score >= 50:
        opening = "Average answer. You have the right direction, but you should add more detail and examples."
    else:
        opening = "Your answer needs improvement. Try to answer directly and include more important concepts."

    matched_text = ", ".join(matched) if matched else "none"
    missing_text = ", ".join(missing[:4]) if missing else "none"

    return (
        f"{opening}\n"
        f"Matched keywords: {matched_text}.\n"
        f"Suggested keywords to include: {missing_text}.\n"
        f"Reference idea: {sample_answer}"
    )


def _openai_feedback(question: str, answer: str, basic_feedback: str) -> str | None:
    """Optional OpenAI feedback.

    This is skipped automatically unless OPENAI_API_KEY is set and the openai package
    is installed. The project remains fully usable without it.
    """

    if not os.getenv("OPENAI_API_KEY"):
        return None

    try:
        from openai import OpenAI

        client = OpenAI()
        response = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            input=(
                "You are an interview coach. Give concise beginner-friendly feedback.\n"
                f"Question: {question}\n"
                f"Answer: {answer}\n"
                f"System evaluation: {basic_feedback}\n"
                "Return 3 short improvement points."
            ),
        )
        return response.output_text.strip()
    except Exception as exc:
        return f"{basic_feedback}\n\nAI feedback skipped because OpenAI integration failed: {exc}"


def evaluate_answer(question_data: dict, answer: str, use_openai: bool = False) -> EvaluationResult:
    keyword_points, matched, missing = _keyword_score(answer, question_data.get("keywords", []))
    quality_points = _quality_score(answer)
    final_score = max(0, min(100, keyword_points + quality_points))
    grade = _grade(final_score)

    basic_feedback = _basic_feedback(
        final_score,
        matched,
        missing,
        question_data.get("sample_answer", "Add relevant concepts and a short example."),
    )

    feedback = basic_feedback
    if use_openai:
        feedback = _openai_feedback(question_data["question"], answer, basic_feedback) or basic_feedback

    return EvaluationResult(
        score=final_score,
        grade=grade,
        matched_keywords=matched,
        missing_keywords=missing,
        feedback=feedback,
    )
