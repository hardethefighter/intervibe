"""Flask backend for the AI Interview Trainer System."""

from __future__ import annotations

import csv
import random
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, render_template, request

from evaluator import evaluate_answer
from interview_data import QUESTIONS
from resume_analyzer import build_personalized_questions, extract_resume_context
from resume_parser import extract_resume_text


app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
RESULTS_DIR = Path(__file__).parent / "results"
RESULTS_FILE = RESULTS_DIR / "performance_results.csv"
PERSONALIZED_QUESTIONS = {}


def _find_question(question_id: int) -> dict | None:
    if question_id in PERSONALIZED_QUESTIONS:
        return PERSONALIZED_QUESTIONS[question_id]
    return next((question for question in QUESTIONS if question["id"] == question_id), None)


def _save_result(row: dict) -> None:
    RESULTS_DIR.mkdir(exist_ok=True)
    file_exists = RESULTS_FILE.exists()

    with RESULTS_FILE.open("a", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=[
                "timestamp",
                "candidate_name",
                "category",
                "question",
                "answer",
                "score",
                "grade",
                "time_taken_seconds",
            ],
        )
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/api")
def api_home():
    return jsonify(
        {
            "message": "AI Interview Trainer Backend is running",
            "endpoints": ["/categories", "/question?category=HR", "/upload-resume", "/evaluate", "/results"],
        }
    )


@app.get("/categories")
def categories():
    unique_categories = sorted({question["category"] for question in QUESTIONS})
    return jsonify({"categories": unique_categories})


@app.post("/upload-resume")
def upload_resume():
    resume_file = request.files.get("resume")
    skills_text = request.form.get("skills_text", "").strip()

    if not resume_file or not resume_file.filename:
        return jsonify({"error": "Please choose a resume document."}), 400

    try:
        file_bytes = resume_file.read()
        extracted_text = extract_resume_text(resume_file.filename, file_bytes)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400

    if not extracted_text:
        return jsonify({"error": "Could not read text from this resume. Try a text-based PDF, DOCX, or TXT file."}), 400

    context = extract_resume_context(extracted_text, skills_text)
    return jsonify(
        {
            "filename": resume_file.filename,
            "resume_text": extracted_text[:12000],
            "skills_text": ", ".join(context["skills"]),
            "resume_context": context,
        }
    )


@app.errorhandler(413)
def file_too_large(_error):
    return jsonify({"error": "Resume file is too large. Please upload a file under 5 MB."}), 413


@app.get("/question")
def question():
    category = request.args.get("category", "Mixed")
    return jsonify(_select_standard_question(category))


@app.post("/question")
def personalized_question():
    payload = request.get_json(force=True)
    category = payload.get("category", "Mixed")
    resume_text = payload.get("resume_text", "").strip()
    skills_text = payload.get("skills_text", "").strip()

    if resume_text or skills_text:
        pool = build_personalized_questions(category, resume_text, skills_text)
        selected = random.choice(pool)
        unique_id = random.randint(2000, 999999)
        selected = {**selected, "id": unique_id}
        PERSONALIZED_QUESTIONS[unique_id] = selected
        context = extract_resume_context(resume_text, skills_text)
        return jsonify(_question_response(selected, context))

    return jsonify(_select_standard_question(category))


def _select_standard_question(category: str) -> dict:

    if category == "Mixed":
        pool = QUESTIONS
    else:
        pool = [item for item in QUESTIONS if item["category"].lower() == category.lower()]

    if not pool:
        return {"error": "Invalid category. Choose HR, Technical, or Mixed."}

    selected = random.choice(pool)
    return _question_response(selected)


def _question_response(selected: dict, context: dict | None = None) -> dict:
    return {
        "id": selected["id"],
        "category": selected["category"],
        "question": selected["question"],
        "timer_seconds": 120,
        "resume_context": context or {"skills": [], "projects": []},
    }


@app.post("/evaluate")
def evaluate():
    payload = request.get_json(force=True)
    question_id = int(payload.get("question_id", 0))
    answer = payload.get("answer", "").strip()
    candidate_name = payload.get("candidate_name", "Student").strip() or "Student"
    time_taken = int(payload.get("time_taken_seconds", 0))
    use_openai = bool(payload.get("use_openai", False))

    question_data = _find_question(question_id)
    if not question_data:
        return jsonify({"error": "Question not found."}), 404

    if not answer:
        return jsonify({"error": "Answer cannot be empty."}), 400

    result = evaluate_answer(question_data, answer, use_openai=use_openai)

    _save_result(
        {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "candidate_name": candidate_name,
            "category": question_data["category"],
            "question": question_data["question"],
            "answer": answer,
            "score": result.score,
            "grade": result.grade,
            "time_taken_seconds": time_taken,
        }
    )

    return jsonify(
        {
            "score": result.score,
            "grade": result.grade,
            "matched_keywords": result.matched_keywords,
            "missing_keywords": result.missing_keywords,
            "feedback": result.feedback,
        }
    )


@app.get("/results")
def results():
    if not RESULTS_FILE.exists():
        return jsonify({"results": []})

    with RESULTS_FILE.open("r", newline="", encoding="utf-8") as file:
        return jsonify({"results": list(csv.DictReader(file))})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
