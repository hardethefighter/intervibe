"""Command-line demo for the AI Interview Trainer System."""

from __future__ import annotations

import random
import time

from evaluator import evaluate_answer
from interview_data import QUESTIONS


def choose_category() -> str:
    print("Choose interview category:")
    print("1. HR")
    print("2. Technical")
    print("3. Mixed")
    choice = input("Enter choice: ").strip()

    if choice == "1":
        return "HR"
    if choice == "2":
        return "Technical"
    return "Mixed"


def main() -> None:
    print("\nAI Interview Trainer System - CLI Demo")
    name = input("Enter candidate name: ").strip() or "Student"
    category = choose_category()

    if category == "Mixed":
        question_pool = QUESTIONS
    else:
        question_pool = [question for question in QUESTIONS if question["category"] == category]

    selected_question = random.choice(question_pool)
    print(f"\nCandidate: {name}")
    print(f"Category: {selected_question['category']}")
    print(f"Question: {selected_question['question']}")
    print("Timer started. Suggested answer time: 120 seconds.\n")

    start_time = time.time()
    answer = input("Your answer: ").strip()
    time_taken = round(time.time() - start_time)

    result = evaluate_answer(selected_question, answer)

    print("\n--- Interview Result ---")
    print(f"Time taken: {time_taken} seconds")
    print(f"Score: {result.score}/100")
    print(f"Grade: {result.grade}")
    print(result.feedback)


if __name__ == "__main__":
    main()
