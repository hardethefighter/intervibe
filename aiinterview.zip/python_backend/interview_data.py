"""Predefined interview questions and expected keywords.

Each question has:
- id: unique identifier
- category: HR or Technical
- question: text displayed to the user
- keywords: important words/phrases expected in a strong answer
- sample_answer: short reference answer used for guidance
"""

QUESTIONS = [
    {
        "id": 1,
        "category": "HR",
        "question": "Tell me about yourself.",
        "keywords": ["name", "education", "skills", "project", "career", "strength"],
        "sample_answer": (
            "A good answer briefly introduces your background, education, key skills, "
            "important projects, and the role you are aiming for."
        ),
    },
    {
        "id": 2,
        "category": "HR",
        "question": "Why should we hire you?",
        "keywords": ["skills", "learn", "team", "responsible", "project", "value"],
        "sample_answer": (
            "A strong answer connects your skills, attitude, learning ability, and project "
            "experience to the company's needs."
        ),
    },
    {
        "id": 3,
        "category": "HR",
        "question": "What are your strengths and weaknesses?",
        "keywords": ["strength", "weakness", "improve", "example", "honest", "learning"],
        "sample_answer": (
            "Mention one or two real strengths with examples. For weakness, explain what "
            "you are doing to improve."
        ),
    },
    {
        "id": 4,
        "category": "HR",
        "question": "Where do you see yourself in five years?",
        "keywords": ["career", "growth", "skills", "responsibility", "company", "learning"],
        "sample_answer": (
            "A good answer shows realistic career growth, continuous learning, and interest "
            "in taking more responsibility."
        ),
    },
    {
        "id": 5,
        "category": "Technical",
        "question": "Explain object-oriented programming.",
        "keywords": ["class", "object", "inheritance", "encapsulation", "polymorphism", "abstraction"],
        "sample_answer": (
            "OOP is a programming approach based on classes and objects. Its main concepts "
            "are encapsulation, inheritance, polymorphism, and abstraction."
        ),
    },
    {
        "id": 6,
        "category": "Technical",
        "question": "What is the difference between an array and a linked list?",
        "keywords": ["array", "linked list", "memory", "index", "node", "insertion", "deletion"],
        "sample_answer": (
            "Arrays store elements in contiguous memory and support fast index access. "
            "Linked lists use nodes and are better for frequent insertions and deletions."
        ),
    },
    {
        "id": 7,
        "category": "Technical",
        "question": "What is a database primary key?",
        "keywords": ["unique", "null", "identify", "record", "table", "database"],
        "sample_answer": (
            "A primary key uniquely identifies each record in a database table and should "
            "not contain duplicate or null values."
        ),
    },
    {
        "id": 8,
        "category": "Technical",
        "question": "Explain the software development life cycle.",
        "keywords": ["requirement", "design", "development", "testing", "deployment", "maintenance"],
        "sample_answer": (
            "SDLC is a process used to develop software through stages such as requirement "
            "analysis, design, development, testing, deployment, and maintenance."
        ),
    },
    {
        "id": 9,
        "category": "Technical",
        "question": "What is exception handling?",
        "keywords": ["error", "try", "catch", "except", "handle", "runtime", "program"],
        "sample_answer": (
            "Exception handling manages runtime errors so the program can respond safely "
            "instead of crashing unexpectedly."
        ),
    },
    {
        "id": 10,
        "category": "Technical",
        "question": "What is an API?",
        "keywords": ["application", "interface", "request", "response", "service", "communication"],
        "sample_answer": (
            "An API is an application programming interface that allows two software systems "
            "to communicate using requests and responses."
        ),
    },
]
