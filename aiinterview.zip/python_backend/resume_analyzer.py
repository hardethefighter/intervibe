"""Resume and skills based interview question generation."""

from __future__ import annotations

import random
import re


KNOWN_SKILLS = [
    "python",
    "java",
    "javascript",
    "html",
    "css",
    "sql",
    "mysql",
    "mongodb",
    "flask",
    "django",
    "spring",
    "react",
    "node",
    "express",
    "machine learning",
    "artificial intelligence",
    "data analysis",
    "excel",
    "power bi",
    "git",
    "github",
    "api",
    "oop",
    "database",
    "web development",
    "android",
    "c",
    "c++",
]


PROJECT_PATTERNS = [
    r"project[s]?\s*[:\-]\s*([^\n\r.]+)",
    r"developed\s+([^\n\r.]+)",
    r"built\s+([^\n\r.]+)",
    r"created\s+([^\n\r.]+)",
]


def extract_resume_context(resume_text: str, skills_text: str) -> dict:
    combined = f"{resume_text}\n{skills_text}".lower()
    explicit_skills = _split_skills(skills_text)
    detected_skills = [skill for skill in KNOWN_SKILLS if _has_skill(combined, skill)]

    skills = []
    for skill in explicit_skills + detected_skills:
        normalized = skill.strip().lower()
        if normalized and normalized not in skills:
            skills.append(normalized)

    return {
        "skills": skills[:8],
        "projects": _extract_projects(resume_text)[:3],
    }


def build_personalized_questions(category: str, resume_text: str, skills_text: str) -> list[dict]:
    context = extract_resume_context(resume_text, skills_text)
    skills = context["skills"]
    projects = context["projects"]

    questions = []
    question_id = 1000

    if category in ("Mixed", "HR"):
        questions.extend(
            [
                {
                    "id": question_id,
                    "category": "Resume HR",
                    "question": "Walk me through your resume and explain why your skills fit this role.",
                    "keywords": ["resume", "skills", "project", "role", "experience", "learning"] + skills[:3],
                    "sample_answer": (
                        "Connect your education, projects, skills, and career goal to the role. "
                        "Mention the strongest skills from your resume."
                    ),
                },
                {
                    "id": question_id + 1,
                    "category": "Resume HR",
                    "question": "Which project or achievement from your resume are you most proud of, and why?",
                    "keywords": ["project", "problem", "solution", "role", "result", "learned"] + skills[:2],
                    "sample_answer": (
                        "Choose one project, explain the problem, your contribution, tools used, "
                        "result, and what you learned."
                    ),
                },
            ]
        )
        question_id += 2

    if category in ("Mixed", "Technical"):
        for skill in skills[:5]:
            questions.append(
                {
                    "id": question_id,
                    "category": "Resume Technical",
                    "question": f"You mentioned {skill.title()} in your resume. Explain how you used it in a project.",
                    "keywords": [skill, "project", "problem", "implementation", "result", "example"],
                    "sample_answer": (
                        f"A strong answer explains where {skill.title()} was used, why it was selected, "
                        "how it was implemented, and what result it produced."
                    ),
                }
            )
            question_id += 1

            questions.append(
                {
                    "id": question_id,
                    "category": "Resume Technical",
                    "question": f"What are the important concepts or features of {skill.title()} that you know?",
                    "keywords": [skill, "concept", "feature", "example", "advantage", "use"],
                    "sample_answer": (
                        f"Define {skill.title()}, describe important concepts or features, and give "
                        "one simple example from your work."
                    ),
                }
            )
            question_id += 1

    for project in projects:
        questions.append(
            {
                "id": question_id,
                "category": "Resume Project",
                "question": f"Your resume mentions {project}. Explain the project architecture and your contribution.",
                "keywords": ["architecture", "module", "database", "frontend", "backend", "contribution", "testing"],
                "sample_answer": (
                    "Explain the project goal, main modules, technologies used, your role, "
                    "testing approach, and final result."
                ),
            }
        )
        question_id += 1

    if not questions:
        questions.append(
            {
                "id": 1999,
                "category": "Resume Based",
                "question": "Tell me about the main skills in your resume and how you have used them.",
                "keywords": ["skills", "project", "example", "experience", "learned", "result"],
                "sample_answer": (
                    "List your strongest skills, connect them with projects, and explain what "
                    "you achieved or learned."
                ),
            }
        )

    random.shuffle(questions)
    return questions


def _split_skills(skills_text: str) -> list[str]:
    return [
        skill.strip()
        for skill in re.split(r"[,;\n|]+", skills_text)
        if skill.strip()
    ]


def _has_skill(text: str, skill: str) -> bool:
    escaped = re.escape(skill)
    return bool(re.search(rf"(?<![a-z0-9+#]){escaped}(?![a-z0-9+#])", text))


def _extract_projects(resume_text: str) -> list[str]:
    projects = []
    for pattern in PROJECT_PATTERNS:
        for match in re.findall(pattern, resume_text, flags=re.IGNORECASE):
            cleaned = re.sub(r"\s+", " ", match).strip(" -:")
            if 4 <= len(cleaned) <= 80 and cleaned.lower() not in [p.lower() for p in projects]:
                projects.append(cleaned)
    return projects
